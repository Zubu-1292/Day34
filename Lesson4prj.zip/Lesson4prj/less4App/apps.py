from django.apps import AppConfig


class Less4AppConfig(AppConfig):
    name = 'less4App'
