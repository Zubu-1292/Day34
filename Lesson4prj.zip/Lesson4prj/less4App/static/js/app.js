
function hello(){
  alert("Welcome !!!");
}
